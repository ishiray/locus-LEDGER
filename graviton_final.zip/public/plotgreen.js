function getDistance(pointA_lat, pointA_long, pointB_lat, pointB_long, pointC_lat, pointC_long) {
    
    console.log(pointA_lat, pointA_long, pointB_lat, pointB_long, pointC_lat, pointC_long);
    //alert('hi');
    let [x1, y1] = [pointA_lat, pointA_long];
    let [x2, y2] = [pointB_lat, pointB_long];
    let [x3, y3] = [pointC_lat, pointC_long];

//    max_height = 30;
//    max_width = 40;

//    centre_x = 860/2;
//    centre_y = 680/2;

//    x1 = 111139*(x1 - x2)/max_height * (860/2) + centre_x
//    y1 = 111139*(y1 - y2)/max_height * (860/2) + centre_y

//    x2 = 860/2;
//    y2 = 680/2;

//    x3 = 111139*(x3 - x2)/max_height * (860/2) + centre_x
//    y3 = 111139*(y3 - y2)/max_height * (860/2) + centre_y

//    console.log(x1, y1, x2, y2, x3, y3);

   draw(x2, y2);
   draw1(x1, y1);
   draw_black(x3, y3);

   return;


    distance1 = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    distance2 = Math.sqrt(Math.pow(x3 - x1, 2) + Math.pow(y3 - y1, 2));
    distance1 = distance1 *100000;
    distance2 = distance2*100000;
    if(distance1<distance2){
        if (distance1 < 50 ) {
            draw(x1, y1);
            draw1(x2,y2);
            //showImage(x2,y2);
            draw1(x3,y3);
//             // draw a green dot'
//             alert(distance1);
//             const canvas = document.getElementById('canvas');
//             const ctx = canvas.getContext('2d');
      
//             const dotRadius = 10;
//             const dotSpacing = 20;
      
//             ctx.fillStyle = '#00FF00'; // Green color
      
//             for (let x = 0; x < canvas.width; x += dotSpacing) {
//               for (let y = 0; y < canvas.height; y += dotSpacing) {
//                 ctx.beginPath();
//                 ctx.arc(x + dotRadius, y + dotRadius, dotRadius, 0, Math.PI * 2);
//                 ctx.fill();
//               }
//             }
//             // const canvas = document.getElementById('canvas');
//             // const context = canvas.getContext('2d');
//             // context.beginPath();
//             // context.arc(x1, y1, 5, 0, 2 * Math.PI, false);
//             // context.fillStyle = 'green';
//             // context.fill();
//             //draw();
        }
        else{
            draw_black(x1, y1);
        }
        
     return distance1;
   }
    else if(distance1>distance2){
        if (distance2 < 50 ) {
            draw(x1, y1);
            draw1(x2,y2);
            draw1(x3,y3);
//             // draw a green dot
//             const canvas = document.getElementById('canvas');
//             const context = canvas.getContext('2d');
//             context.beginPath();
//             context.arc(x1, y1, 5, 0, 2 * Math.PI, false);
//             context.fillStyle = 'green';
//             context.fill();
        }
        else{
            draw_black(x1, y1);
        }
        return distance2;
    }
    else 
    {
        if (distance1<50)
        {
            draw(x1, y1);
//             const canvas = document.getElementById('canvas');
//             const context = canvas.getContext('2d');
//             context.beginPath();
//             context.arc(x1, y1, 5, 0, 2 * Math.PI, false);
//             context.fillStyle = 'green';
//             context.fill();
        }
        else {
            draw_black(x1, y1);
        }
        return distance1;
    }
//     alert('OGMNGNGNGNGNNGG');
 }
function draw(x,y)
  {
    
var canvas = document.getElementById('circle');
// console.log(canvas);
if (canvas.getContext)
{
var ctx = canvas.getContext('2d'); 
// var X = canvas.width / 2;
// var Y = canvas.height / 2;
var X = x;
var Y = y;

var R =5;
ctx.beginPath();
ctx.arc(X, Y, R, 0, 2 * Math.PI, false);
ctx.lineWidth = 3;
ctx.strokeStyle = '#00FF00';
ctx.stroke();
}
 }

function draw1(x,y)
  {
    
var canvas = document.getElementById('circle');
// console.log(canvas);
if (canvas.getContext)
{
var ctx = canvas.getContext('2d'); 
// var X = canvas.width / 2;
// var Y = canvas.height / 2;
var X = x;
var Y = y;

var R = 5;
ctx.beginPath();
ctx.arc(X, Y, R, 0, 2 * Math.PI, false);
ctx.lineWidth = 3;
ctx.strokeStyle = '#FF0000';
ctx.stroke();
}

}
function draw_black(x,y)
  { 
    
var canvas = document.getElementById('circle');
// console.log(canvas);
if (canvas.getContext)
{
var ctx = canvas.getContext('2d'); 
// var X = canvas.width / 2;
// var Y = canvas.height / 2;
var X = x;
var Y = y;

var R = 5;
ctx.beginPath();
ctx.arc(X, Y, R, 0, 2 * Math.PI, false);
ctx.lineWidth = 3;
ctx.strokeStyle = '#000000';
ctx.stroke();

}
}

function showImage(x,y) {
    // myImage : ID of image on which to place new image

    var image = document.getElementById('car.png');

    console.log(image.width);

    margin = 20;

    l = image.offsetLeft;
    t = image.offsetTop;
    w = image.width;
    h = image.height;

    // Location inside the image
    offX = x;
    offY = y;

    if(offX > margin) offX -= margin;
    if(offY > margin) offY -= margin;

    l += offX;
    t += offY;

    var newImage = document.createElement("img");
    newImage.setAttribute('src', '1.jpg');
    newImage.setAttribute('class', 'overlays');
    newImage.style.left = l + "px";
    newImage.style.top = t + "px";
    document.body.appendChild(newImage);
}

async function get_locations() {
    const response = await fetch('/current_location');
    const data = JSON.parse(await response.json());

    return data;
}

async function draw_locations() {
    const data = await get_locations();
    // console.log(data);

    
    let own_lat;
    let own_lng;

    let car2_lat;
    let car2_lng;

    let car3_lat;
    let car3_lng;


    for (const obj of data){
        console.log(obj);
        if (obj.username == 'own') {
            own_lat = obj?.location?.lat;
            own_lng = obj?.location?.lng;
        }
        else if (obj.username == 'car2') {
            car2_lat = obj?.location?.lat;
            car2_lng = obj?.location?.lng;
        }
        else {
            car3_lat = obj?.location?.lat;
            car3_lng = obj?.location?.lng;
        }
    }

    // console.log('own', own_lat);

    getDistance(own_lat ?? 1000, own_lng ?? 1000, car2_lat ?? 1000, car2_lng ?? 1000, car3_lat ?? 1000, car3_lng ?? 1000);
}


setInterval(() => {
    draw_locations();
}, 500);


// getDistance(12.9353838, 77.5342727, 12.9353694, 77.5342588, 12.9353636, 77.5342599)



